// C:\> py.exe udrl.py xxd .\beacon_x64.bin .\library\DebugDLL.x64.h
unsigned char debug_dll[] = {
	0x90 //Change Me
};
