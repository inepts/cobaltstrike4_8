#pragma once
#include "Windows.h"
#include "beacon_user_data.h"

BOOL ResolveSyscalls(SYSCALL_API* syscalls);
