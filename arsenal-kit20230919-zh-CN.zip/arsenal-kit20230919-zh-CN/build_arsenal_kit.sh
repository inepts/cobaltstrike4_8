#!/usr/bin/env bash

###################################################################
#
# Cobalt Strike Kit
#
# (c) 2012-2023 Fortra, LLC 及其关联公司。所有商标和注册商标均为其各自所有者的财产。
#
# Cobalt Strike Arsenal Kit 的构建脚本
###################################################################

## 包含配置脚本
. ./arsenal_kit.config

## 初始化 Aggressor 脚本的 kits 字符串
kits_string=""

########################
## 函数
function banner () {
cat << "EOF" 
    ___                               ____ __ _ __ 
   /   |  _____________  ____  ____ _/ / //_/(_) /_
  / /| | / ___/ ___/ _ \/ __ \/ __ `/ / ,<  / / __/
 / ___ |/ /  (__  )  __/ / / / /_/ / / /| |/ / /_  
/_/  |_/_/  /____/\___/_/ /_/\__,_/_/_/ |_/_/\__/   
Cobalt Strike Arsenal Kit                                                                 
(c) 2012-2023 Fortra, LLC 及其关联公司。所有商标和注册商标均为其各自所有者的财产。
-----------------------------------------------------------------
EOF
}

# 使输出看起来更漂亮...
kit_name="arsenal kit"

function print_good () {
   echo -e "[${kit_name}] \x1B[01;32m[+]\x1B[0m $1"
}

function print_error () {
   echo -e "[${kit_name}] \x1B[01;31m[-]\x1B[0m $1"
}

function print_info () {
   echo -e "[${kit_name}] \x1B[01;34m[*]\x1B[0m $1"
}

########################
## 构建套件

## 创建输出目录
mkdir -p ./${dist_directory}/

## Artifact 套件
function build_artifact_kit () {
    print_good "构建 Artifact Kit"
    cd "${artifactkit_directory}"
    "${artifactkit_directory}/build.sh" "${artifactkit_technique}" "${artifactkit_allocator}" "${artifactkit_stage_size}" "${rdll_size}" "${artifactkit_include_resource}" "${artifactkit_stack_spoof}" "${artifactkit_syscalls_method}" "${artifactkit_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

## Sleepmask 套件
function build_sleepmask_kit () {
    print_good "构建 Sleepmask Kit"
    cd "${sleepmask_directory}"
    "${sleepmask_directory}/build.sh" "${sleepmask_version}" "${sleepmask_sleep_method}" "${sleepmask_mask_text_section}" "${sleepmask_syscalls_method}" "${sleepmask_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

## Process Inject Kit
function build_process_inject_kit () {
    print_good "构建 Process Inject Kit"
    cd "${process_inject_directory}"
    "${process_inject_directory}/build.sh" "${process_inject_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

## UDRL 套件
function build_udrl_kit () {
    print_good "构建 UDRL Kit"
    cd "${udrl_directory}"
    "${udrl_directory}/build.sh" "${rdll_size}" "${udrl_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

## Mimikatz 套件
function build_mimikatz_kit () {
    print_good "构建 Mimikatz Kit"
    cd "${mimikatz_kit_directory}"
    "${mimikatz_kit_directory}/build.sh" "${mimikatz_kit_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

## Resource 套件
function build_resource_kit () {
    print_good "构建 Resource Kit"
    cd "${resource_kit_directory}"
    "${resource_kit_directory}/build.sh" "${resource_kit_dist_directory}"
    if [ $? -gt 0 ] ; then
      exit 2
    fi
}

########################
## 开始
banner

##### Cobalt Strike Arsenal Kit
cd "${cwd}"

# 复制基本模板
cp ./templates/arsenal_kit.cna.template ./${dist_directory}/arsenal_kit.cna

##### Artifact Kit
if [ ${include_artifact_kit} = "true" ]; then
    if [[ "${artifactkit_technique}" != "${artifactkit_technique%[[:space:]]*}" ]] ; then
      print_error "Artifact 绕过技术无效：'${artifactkit_technique}'"
      print_info "构建 Arsenal Kit 时仅提供 Artifact Kit 的单个绕过技术。"
      exit 1;
    fi

    build_artifact_kit

    # 默认情况下，构建脚本将输出保存到 artifact/technique/*。将其移动到 dist/artifact/
    print_good "将绕过技术 '${artifactkit_technique}' 的工件移动到 '${artifactkit_dist_directory}'"
    mv "${artifactkit_dist_directory}/${artifactkit_technique}"/* "${artifactkit_dist_directory}/"
    rm -rf "${artifactkit_dist_directory}/${artifactkit_technique}"

    cd "${cwd}"
    print_good "将 Artifact Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    cat "${artifactkit_dist_directory}/artifact.cna" >> ./${dist_directory}/arsenal_kit.cna

    echo ""
fi

##### Sleep Mask Kit
if [ ${include_sleepmask_kit} = "true" ]; then
    build_sleepmask_kit

    cd "${cwd}"
    print_good "将 Sleepmask Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    cat "${sleepmask_directory}/script_template.cna" >> ./${dist_directory}/arsenal_kit.cna

    echo ""
fi

##### Process Inject Kit
if [ ${include_process_inject_kit} = "true" ]; then
    build_process_inject_kit

    cd "${cwd}"
    print_good "将 Process Inject Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    cat "${process_inject_directory}/script_template.cna" >> ./${dist_directory}/arsenal_kit.cna

    echo ""
fi

##### UDRL Kit
if [ ${include_udrl_kit} = "true" ]; then
    build_udrl_kit

    cd "${cwd}"
    print_good "将 UDRL Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    sed "s/__RDLL_SIZE__/${rdll_size}/" "${udrl_directory}/script_template.cna" >> ${dist_directory}/arsenal_kit.cna

    echo ""
fi

##### Mimikit
if [ ${include_mimikatz_kit} = true ]; then
    build_mimikatz_kit

    cd "${cwd}"
    print_good "将 Mimikatz Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    cat "${mimikatz_kit_directory}/script_template.cna" >> ./${dist_directory}/arsenal_kit.cna

    echo ""
fi

##### Resource Kit
if [ ${include_resource_kit} = true ]; then
    build_resource_kit

    cd "${cwd}"
    print_good "将 Resource Kit 钩子添加到 ${dist_directory}/arsenal_kit.cna 文件"
    cat "${resource_kit_directory}/script_template.cna" >> ./${dist_directory}/arsenal_kit.cna

    echo ""
fi
