# 用户定义的反射加载器 Visual Studio (UDRL-VS)

这个工具包包含了用户定义的反射加载器 Visual Studio (UDRL-VS) 模板。UDRL-VS 是一个包含函数库，用于帮助支持反射加载器的开发。它附带了两篇博客文章，解释了其背后的原因并介绍了一些关键概念。

这些文章可以在以下位置找到：

* https://cobaltstrike.com/blog/revisiting-the-udrl-part-1-simplifying-development
* https://cobaltstrike.com/blog/revisiting-the-udrl-part-2-obfuscation-masking

UDRL-VS 工具包主要用作一个函数库。然而，`udrl-vs/examples` 目录包含示例加载器，用于演示不同的技术。以下是对这些示例的简要描述，有关如何使用/调试它们的更多信息可以在 README 文件中找到 - `/examples/<loader>/README.md`。

* `default-loader` - 基于 Stephen Fewer 原始加载器的简单反射加载器。它可以编译为前置式 "Double Pulsar" 风格加载器或被压制的 "Stephen Fewer" 风格加载器。
* `obfuscation-loader` - 使用自定义混淆和掩码方法的 "Double Pulsar" 风格加载器。

## 先决条件:

必需的:

* 一台 x64 Windows 10/11 开发计算机 (没有安全解决方案)
* Visual Studio Community/Pro/Enterprise 2022 (安装了 C++ 桌面开发)。
* Python3 (x64 v3.9+) - 完整安装了 Python Launcher for Windows (`py.exe`)。
* Python 依赖项 (`py.exe -m pip install -r requirements.txt`)。
* 一个有许可证的 teamserver。

可选的:

* Python3 (x86) - 用于测试 x86 负载 (需要 `pefile`)。

**注意:** Visual Studio 项目预期使用 `py.exe`，这是 Windows 的 Python Launcher - https://docs.python.org/3/using/windows.html#launcher。这是默认情况下由 Windows Python 安装程序安装的，但如果没有设置好，构建将失败。

## 创建一个加载器

要从头开始创建一个新的加载器:

* 打开 udrl-vs.sln 解决方案。
* 创建一个新项目 (文件->新建->项目)。
  * 选择 C++ 控制台应用。
  * 为加载器命名，在 "解决方案" 下确保选择 "添加到解决方案"。
* 添加对 UDRL-VS 函数库的引用。
  * 右键单击新项目->添加->引用并选中 "library"。
* 应用提供的属性文件 (`loader.prop`)。
  * 打开 Visual Studio 的属性管理器 (位置可能有所不同，请使用搜索栏 "属性管理器")。
  * 右键单击新项目->添加现有属性表。
  * 添加 loader.prop 以应用所需的项目设置。
* 向项目添加 Debug DLL - `py.exe .\udrl.py xxd <path\to\beacon_x64.bin> .\library\DebugDLL.x64.h`
* 创建一个 `ReflectiveLoader.cpp` 源文件和一个 `ReflectiveLoader.h` 头文件。
* 开始开发。

## 其他考虑事项

在开发 UDRL 时，请注意以下内容:

* 留意脚本控制台，如果 BEACON_RDLL_GENERATE* 钩子失败，teamserver 将输出默认的 Beacon 负载，这可能会引起混淆。
* teamserver 需要能够解析 Beacon 以应用转换。在执行所有其他修改之后，修改 `MZ`、`PE` 和 `e_lfanew` 等标头值。
* "前置" 风格加载器将增加 Beacon 的大小。在通过 Arsenal 工具包生成工件时，请确保考虑到这一点。

## 休眠掩码

休眠掩码工具包是 Cobalt Strike 避检策略的一个重要部分。可以将休眠掩码工具包与 UDRL 一起使用。但是，需要强调一些影响其操作的配置选项。

`obfuscate` 标志不会混淆 UDRL 的 Beacon，因为您应该通过 Aggressor 脚本应用修改。但是，将 `obfuscate` 设置为 true 将告诉休眠掩码工具包，PE 标头未复制到加载 Beacon 的新内存分配中（这是默认加载器应用的转换之一）。这意味着您的加载器也不应复制 PE 标头，否则它将不会被掩码。

此外，默认情况下 `userwx` 设置为 true，因此休眠掩码工具包将期望 Beacon 内存为 RWX，并尝试在 .text 部分执行其正常掩码操作。为了避免 RWX 内存并在 .text 部分使用 RX 内存，`userwx` 应设置为 false，应在休眠掩码工具包中应用 `mask_text_section`。

## 处理超过 5K 的 UDRL

"Stephen Fewer" 风格的加载器被压制到 Beacon 中。因此，考虑其大小非常重要。默认的 `stagesize` 值支持 5K 反射加载器。然而，存在一个 Aggressor 钩子，可以将其增加到 100K。


```

# ------------------------------------
# $1 = DLL 文件名
# $2 = 架构
# ------------------------------------
set BEACON_RDLL_SIZE {
   warn("Running 'BEACON_RDLL_SIZE' for DLL " . $1 . " with architecture " . $2);
   return "100";
}# ------------------------------------
```
--- 

## UDRL-VS 模板

此模板基于 Stephen Fewer 的经典反射
加载器 https://github.com/stephenfewer/ReflectiveDLLInjection。
已进行修改以简化它并删除未使用的代码。
还添加了新代码，以帮助简化开发和调试。

## 参考资料

- Stephen Fewer 的反射 DLL 注入: https://github.com/stephenfewer/ReflectiveDLLInjection
- Bobby Cooke 和 Santiago Pecin 的 BokuLoader: https://github.com/boku7/BokuLoader
- Kyle Avery 的 AceLdr: https://github.com/kyleavery/AceLdr
- Austin Hudson 的 TitanLdr: https://github.com/realoriginal/titanldr-ng

## 修改

鼓励您对此代码进行修改并在您的项目中使用。请不要重新分发此源代码。它不是开源的。它作为授权的 Cobalt Strike 用户的福利提供。

## 许可证

此代码受 Cobalt Strike 的最终用户许可协议约束。完整的许可协议位于：

https://www.cobaltstrike.com/license

此代码受 Stephen Fewer 的反射加载器项目许可协议约束。完整的许可协议位于：

https://github.com/stephenfewer/ReflectiveDLLInjection/blob/master/LICENSE.txt
