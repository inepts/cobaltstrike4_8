# 资源工具包

此软件包包含 Cobalt Strike 在其工作流程中使用的 PowerShell、Python 和 VBA 模板。您可以修改这些模板以逃避基于签名的检测，或自定义 Cobalt Strike 如何在其工作流程中使用这些模板。

# 加载到 Cobalt Strike

要使用资源工具包，请将 resources.cna 加载到 Cobalt Strike 中。

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<output directory>/resource/resources.cna`

# 资源
```
compress.ps1:
	这是 Cobalt Strike 使用的 PowerShell 模板，用于运行 GZIP 压缩的 PowerShell 脚本。

	受影响的功能：
	Payload Generator [PowerShell 命令输出]
	脚本化 Web 交付 (PowerShell)
	Beacon: powershell-import, psexec_psh, wmi
```

```
template.exe.hta
	这是 Cobalt Strike 使用的 HTA 模板，用于下发和运行可执行文件。

	受影响的功能：
		HTML 应用程序 (可执行)
```

```
template.psh.hta
	这是 Cobalt Strike 使用的 HTA 模板，用于运行 PowerShell 载荷。

	受影响的功能：
		HTML 应用程序 (PowerShell)
```

```
template.py
	这是 Cobalt Strike 使用的 Python 模板，用于运行 x86 和 x64 载荷。

	受影响的功能：
		脚本化 Web 交付 (Python)
```

```
template.vbs
	这是 Cobalt Strike 使用的 VBScript 模板，用于运行 VBA 宏载荷。

	受影响的功能：
		HTML 应用程序 (VBA)
		脚本化 Web 交付 (regsvr32)
```

```
template.x64.ps1
	这是 Cobalt Strike 使用的 PowerShell 模板，用于运行 x64 载荷。

	受影响的功能：
		Windows EXE (无分段) [PowerShell 输出]
```

```
template.x86.ps1
	这是 Cobalt Strike 使用的 PowerShell 模板，用于运行 x86 载荷。

	受影响的功能：
		HTML 应用程序 (PowerShell)
		脚本化 Web 交付 (PowerShell)
		Windows EXE (无分段) [PowerShell 输出]
		Beacon: spawnas, spawnu, psexec_psh, winrm, wmi
```

```
template.x86.vba
	这是 Cobalt Strike 使用的 VBA 模板，用于运行 x86 载荷。

	受影响的功能：
		HTML 应用程序 (VBA)
		Microsoft Office 宏攻击
		脚本化 Web 交付 (regsvr32)
```

# 其他
```
set POWERSHELL_COMMAND
	控制 Cobalt Strike 中的 PowerShell 命令的形式

	A受影响的功能：
		HTML 应用程序 (PowerShell)
		Payload Generator 对话框
		Beacon: powershell, winrm, wmi, elevate uac-token-elevate, spawnas, 
	        spawnu, psexec_psh
	函数：&powershell
```

```
set POWERSHELL_DOWNLOAD_CRADLE
	控制 Cobalt Strike 自动化中的 PowerShell 下载工作台的形式

	受影响的功能：
		Beacon: elevate, uac-token-bypass, powershell-import, spawnas, spawnu
		函数：&beacon_host_script, &beacon_host_imported_script

```


# 修改

鼓励您对此代码进行修改并在您的任务中使用。请勿重新分发此源代码。它不是开源的。它提供给已获许可的 Cobalt Strike 用户作为福利。

# 许可

此代码受Cobalt Strike的最终用户许可协议约束。完整的许可协议位于：

[https://www.cobaltstrike.com/license](https://www.cobaltstrike.com/license)
