# 进程注入工具包

进程注入是Cobalt Strike后期渗透的核心组件。直到现在，使用内置的fork&run注入技术是一个选择。这种方法在稳定性上表现出色，但在OPSEC方面有一些成本。

Cobalt Strike 4.5现在支持两个新的Aggressor脚本挂钩 `PROCESS_INJECT_SPAWN` 和 `PROCESS_INJECT_EXPLICIT`。这些挂钩允许用户在执行后期渗透命令时定义如何实现fork&run和显式注入技术，而不是使用内置技术。

这些技术的实现通过一个Beacon对象文件（BOF）和一个Aggressor脚本函数。

这两个挂钩将涵盖大多数后期渗透命令，每个部分中将列出它们。然而，以下是一些不使用这些挂钩的例外情况。

#### 例外情况
Beacon命令    | Aggressor脚本函数
-----------------|--------------------------
N/A              | &bdllspawn
execute-assembly | &bexecute_assembly
shell	         | &bshell

## 参考资料

- https://www.cobaltstrike.com/blog/process-injection-update-in-cobalt-strike-4-5/
- https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics_aggressor-scripts/as-resources_hooks.htm#PROCESS_INJECT_EXPLICIT
- https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics_aggressor-scripts/as-resources_hooks.htm#PROCESS_INJECT_SPAWN

## 工作原理

内置的fork和run进程注入技术可以通过 `PROCESS_INJECT_SPAWN` 和 `PROCESS_INJECT_EXPLICIT` 挂钩进行更改。

此工具包提供以下内容：
- 通过BOF实现内置技术的源代码
- 通过Aggressor脚本模板实现挂钩
- 用于编译和生成分发目录的构建脚本

#### PROCESS_INJECT_SPAWN

用于允许用户定义在使用Beacon对象文件（BOF）执行后期渗透命令时如何实现fork和run进程注入技术的挂钩。

#### PROCESS_INJECT_EXPLICIT

用于允许用户定义在使用Beacon对象文件（BOF）执行后期渗透命令时如何实现显式进程注入技术的挂钩。

# 使用方法

```
./build.sh <输出目录>
```


# 加载到Cobalt Strike

要使用进程注入工具包，请将`processinject.cna`加载到Cobalt Strike中。

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<输出目录>/process_inject/processinject.cna`

# 修改

鼓励您对此代码进行修改并在您的渗透测试中使用。

# 许可

此代码不受Cobalt Strike最终用户许可协议的约束。
