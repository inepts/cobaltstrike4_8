# SleepMask（睡眠遮罩）

此软件包包含示例的 sleep_mask 源代码，用于支持在内存中掩盖和取消遮罩 Beacon。

# SleepMask 版本 47

用于 Cobalt Strike 版本 4.7 和 4.8

src47 目录中的文件包含了用于支持特定类型的 Beacon 的两种 sleep mask 类型的函数。

类型       |     支持
-----------|----------------------------------------
默认      |     HTTP、HTTPS 和 DNS Beacons
pivot      |     SMB 和 TCP Beacons

# SleepMask 版本 49

用于 Cobalt Strike 版本 4.9 及更高版本

src49 目录中的文件包含了用于支持特定类型的 Beacon 的两种 sleep mask 类型的函数。

类型       |     支持
-----------|----------------------------------------
默认      |     HTTP、HTTPS 和 DNS Beacons
pivot      |     SMB 和 TCP Beacons

# 工作原理

Cobalt Strike 生成 Beacon 时将调用 BEACON_SLEEP_MASK 钩子，允许用户覆盖默认的 sleep mask 代码。

BEACON_SLEEP_MASK 钩子传入正在生成的类型和体系结构。此信息用于打开包含 sleep_mask 代码的适当对象文件，然后将 sleep_mask 代码从中提取并更新到 Beacon 中，以取代默认值。

# 适用于 Cobalt Strike 4.7 和 4.8

使用 Cobalt Strike 4.7 版本后，sleep mask 已经重新设计，现在将作为 Beacon Object File (BOF) 在其自己的内存区域中执行。内存区域是使用 VirtualAlloc 分配的。

存在不能超过 N 字节的代码大小要求。如果发生这种情况，将使用默认的 sleep mask 代码。
- 4.7 版本的最大大小为 8192 字节（8 KB）
- 4.8 版本的最大大小为 16384 字节（16 KB）

可以使用 Beacon API 函数，但只能在代码部分被遮蔽之前和在代码部分被解除遮蔽之后使用。

支持使用 LIBRARY$Function 语法的外部函数。

src47 目录中还包含其他文件，以支持额外的 sleep mask 功能。这些功能默认情况下处于禁用状态，可以通过更新 src47/sleepmask.c 中找到的定义标签来启用。

其中一项 sleep mask 功能是提供代码来实现使用 NtProtectVirtualMemory 的系统调用，而不是使用 VirtualProtect。使用了 SysWhispers3 公共存储库生成了系统调用的代码，然后进行了额外的修改以使其与 sleep mask 工具包一起使用。

在 SysWhispers3 项目中引用的系统调用方法被称为 'jumper'，在 sleep mask 工具包中称为 'indirect'，以与 Cobalt Strike 术语保持一致。这会影响文件名称、构建脚本和文档，但不会影响生成文件中的代码。

文件                           |  描述
-------------------------------|-------------------------------------
beacon.h                       |  定义可用的内部 beacon API
bofdefs.h                      |  定义 Windows API 的动态函数解析原型
cfg.c                          |  定义 Control Flow Guard (CFG) 覆盖（仅限 x64）
common_mask.c                  |  通用遮蔽函数
evasive_sleep.c                |  使用 CreateTimerQueueTimer 对 sleep mask 代码进行模糊化（仅限 x64）
evasive_sleep_stack_spoof.c    |  与 evasive_sleep.c 相同，但包括堆栈欺骗功能（仅限 x64）
log_sleepmask_parms.c          |  将信息记录到 beacon 控制台中（用于调试）
mask_text_section.c            |  在睡眠之前遮蔽 beacon 的文本部分。
sleepmask.c                    |  定义默认 sleep mask 类型的 sleep mask 函数
sleepmask_pivot.c              |  定义枢轴 sleep mask 类型的 sleep mask 函数
syscall.h                      |  与系统调用源文件一起使用的头文件
syscalls_embedded.c            |  使用内嵌方法实现系统调用
syscalls_indirect.c            |  使用间接方法实现系统调用
syscalls_indirect_randomized.c |  使用间接随机化方法实现系统调用

警告:
 - 默认情况下，使用 evasive_sleep 功能时，Control Flow Guard (CFG) 覆盖被禁用。
 - 对于受 CFG 保护的进程的进程注入，需要 CFG 覆盖。
 - 选择性地使用 evasive_sleep 功能时，artifactkit_stack_spoof 设置为 true 将无法使用。
 - 在 evasive_sleep_stack_spoof.c 中提供的欺骗堆栈是根据特定版本的 Windows 10 的值确定的。请参阅有关 Evasive Sleep Stack Spoof 信息的部分。

# 适用于 Cobalt Strike 4.9 和更高版本

使用 Cobalt Strike 4.7 版本后，sleep mask 已经重新设计，现在将作为 Beacon Object File (BOF) 在其自己的内存区域中执行。内存区域是使用 VirtualAlloc 分配的。

存在不能超过 N 字节的代码大小要求。如果发生这种情况，将使用默认的 sleep mask 代码。
- 4.9 版本的最大大小为 16384 字节（16 KB）

可以使用 Beacon API 函数，但只能在代码部分被遮蔽之前和在代码部分被解除遮蔽之后使用。

支持使用 LIBRARY$Function 语法的外部函数。

src49 目录中还包含其他文件，以支持额外的 sleep mask 功能。这些功能默认情况下处于禁用状态，可以通过更新 src49/sleepmask.c 中找到的定义标签来启用。

其中一项 sleep mask 功能是提供代码来实现使用 NtProtectVirtualMemory 的系统调用，而不是使用 VirtualProtect。使用了 SysWhispers3 公共存储库生成了系统调用的代码，然后进行了额外的修改以使其与 sleep mask 工具包一起使用。

在 SysWhispers3 项目中引用的系统调用方法被称为 'jumper'，在 sleep mask 工具包中称为 'indirect'，以与 Cobalt Strike 术语保持一致。这会影响文件名称、构建脚本和文档，但不会影响生成文件中的代码。

文件                           |  描述
-------------------------------|-------------------------------------
beacon.h                       |  定义可用的内部 beacon API
bofdefs.h                      |  定义 Windows API 的动态函数解析原型
cfg.c                          |  定义 Control Flow Guard (CFG) 覆盖（仅限 x64）
common_mask.c                  |  通用遮蔽函数
evasive_sleep.c                |  使用 CreateTimerQueueTimer 对 sleep mask 代码进行模糊化（仅限 x64）
evasive_sleep_stack_spoof.c    |  与 evasive_sleep.c 相同，但包括堆栈欺骗功能（仅限 x64）
log_sleepmask_parms.c          |  将信息记录到 beacon 控制台中（用于调试）
mask_text_section.c            |  在睡眠之前遮蔽 beacon 的文本部分。
sleepmask.c                    |  定义默认 sleep mask 类型的 sleep mask 函数
sleepmask_pivot.c              |  定义枢轴 sleep mask 类型的 sleep mask 函数
syscall.h                      |  与系统调用源文件一起使用的头文件
syscalls_embedded.c            |  使用内嵌方法实现系统调用
syscalls_indirect.c            |  使用间接方法实现系统调用
syscalls_indirect_randomized.c |  使用间接随机化方法实现系统调用

警告:
- 默认情况下，使用 evasive_sleep 功能时，Control Flow Guard (CFG) 覆盖被禁用。
- 对于受 CFG 保护的进程的进程注入，需要 CFG 覆盖。
- 选择性地使用 evasive_sleep 功能时，artifactkit_stack_spoof 设置为 true 将无法使用。
- 在 evasive_sleep_stack_spoof.c 中提供的欺骗堆栈是根据特定版本的 Windows 10 的值确定的。请参阅有关 Evasive Sleep Stack Spoof 信息的部分。

# Evasive Sleep 信息

sleep mask 工具包提供了附加的避免技术代码，通常需要启用它，因为默认情况下是禁用的，并且仅支持 x64 系统。这些技术有两种实现，分别位于 evasive_sleep.c 和 evasive_sleep_stack_spoof.c 中。这两种实现都会更改 sleep mask BOF 的内存保护级别，从读写（RW）到只读（RX），模糊化 sleep mask BOF 的内存，并休眠指定的时间。evasive_sleep_stack_spoof.c 文件添加了欺骗堆栈的功能，但是该功能需要针对特定的 Windows 版本才能生效，以使其看起来有效。

要启用这些技术，请在 sleepmask.c 中将 EVASIVE_SLEEP 定义设置为 1。然后再次搜索 EVASIVE_SLEEP 定义，取消注释要使用的实现，默认是 evasive_sleep.c。

在 evasive_sleep 代码（src47）文件中，有一个 ImageSize 和 Img.Length 变量，可能需要根据您的用例进行修改，因为这些值是硬编码的。这将需要在测试虚拟机上测试，以确定为 sleep mask BOF 在内存中分配了多少页，这可以是 2 到 4 页以上。如果不这样做，那么只有前两页会被模糊化。在 evasive_sleep 代码（src49）中，这些值是从 BeaconInformation API 中获取的，因此不再需要进行修改。

evasive_sleep_stack_spoof 实现将需要对目标的 Windows 版本进行额外的研究和测试，因为欺骗的堆栈可能在一个版本上看起来有效，但在另一个版本上看起来不是有效的。原因是目标 DLL 中的偏移可能在版本之间更改，尤其在主要版本之间更改。例如，针对 Windows 10 的堆栈在 Windows 11 上可能看起来不一样。

为了使欺骗的堆栈在目标上看起来有效，您需要研究可比较的 Windows 版本上的有效调用堆栈，以确定在 evasive_sleep_stack_spoof 代码中需要的值。

为了帮助确定这些信息，正在提供一个实用程序进程的代码。该实用程序的源代码位于 arsenal-kit/utils/getFunctionOffset 目录中。构建说明可以在源文件中找到。此实用程序需要在可比较的 Windows 版本上执行。

如何选择要欺骗的调用堆栈。
步骤：
 - 在代表性的 Windows 目标系统上使用 Process Hacker 或类似的实用程序查找要欺骗的堆栈。
 - 将模块、函数和偏移信息用作 arsenal-kit/utils 中的 getFunctionOffset 实用程序的输入，该实用程序位于 getFunctionOffset 目录中。
 - getFunctionOffset 实用程序输出信息，包括用于 set_callstack() 函数中的代码。

注意：应查找以 NtWaitForSingleObject 开头的堆栈。然后使用其他堆栈帧的信息。
注意：模块扩展名是可选的。

使用 getFunctionOffset 辅助工具程序生成代码的示例：
 - getFunctionOffset.exe ntdll.dll TpReleasePool 0x402
 - getFunctionOffset.exe kernel32.dll BaseThreadInitThunk 0x14
 - getFunctionOffset.exe ntdll RtlUserThreadStart 0x21

# 修改

鼓励您对代码、编译器版本或编译器选项进行修改，以防止 sleep mask 被用于识别 Beacon。

在源代码中有一些项目无法修改，因为 Beacon 使用这些项目来填充数据结构以调用 sleep_mask 函数。如果更改这些项目，Beacon 将失败。

以下是列表：
 - 不要更改 MASK_SIZE 值
 - 不要更改 SLEEPMASKP 数据结构
 - 不要更改 ACTION_PIPE_WAIT 或 ACTION_PIPE_PEEK 值（sleepmask_smb.c）
 - 不要更改 SLEEPMASK_PIPE_ARGS 数据结构（sleepmask_smb.c）
 - 不要更改 TCP_ACTION_ACCEPT 值（sleepmask_tcp.c）
 - 不要更改 SLEEPMASK_TCP_ARGS 数据结构（sleepmask_tcp.c）
 - 不要更改 sleep_mask 函数的参数。
 - 不要更改 ACTION_TCP_RECV 或 ACTION_TCP_ACCEPT 值（sleepmask_pivot.c）
 - 不要更改 ACTION_PIPE_WAIT 或 ACTION_PIPE_SEEK 值（sleepmask_pivot.c）
 - 不要更改 SLEEPMASK_ARGS 数据结构（sleepmask_pivot.c）
 - 不要更改 src47/sleepmask.h 中的内容
 - 不要更改 src49/sleepmask.h 中的内容

使用 sleep_mask 版本 47 和 49 代码，您可以更灵活地进行代码修改。

注意：src47 和 src49 目录中的源代码有 "DO NOT MODIFY FILE START" 和 "DO NOT MODIFY FILE END" 注释，指示不应修改的代码的开始和结束行。

注意：SLEEPMASK 部分的指针引用堆内存，因此不要在处理部分之前遮蔽堆内存。

不要重新分发此源代码。这不是开源的。它作为受许可的 Cobalt Strike 用户的福利而提供。

# 用法

```
./build.sh <version> <sleep_method> <mask_text> <syscalls> <output directory>

版本 - sleepmask 版本。有效值[47, 49]
版本 47 支持 Cobalt Strike 4.7 和 4.8
版本 49 支持 Cobalt Strike 4.9 及更高版本
Sleep Method - 选择用于休眠的函数
有效选项：Sleep、WaitForSingleObject
Mask_text - 是否遮蔽 beacon 的文本部分（true 或 false）
Syscalls - 设置系统调用方法
有效值 [none embedded indirect indirect_randomized]
Output Directory - 保存输出的目标目录

```

示例:
```
./build.sh 49 WaitForSingleObject true indirect /tmp/dist
```


您需要以下内容：

- Minimal GNU for Windows Cross-Compiler - apt-get install mingw-w64

# 加载到 Cobalt Strike

要使用 sleep mask object 文件，加载 sleepmask.cna 到 Cobalt Strike。

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<output directory>/sleepmask/sleepmask.cna`

# 许可

此代码受 Cobalt Strike 的最终用户许可协议约束。完整的许可协议位于：

https://www.cobaltstrike.com/license
