# 用户自定义反射加载器

此包含 Cobalt Strike 用户自定义反射加载器工具包的源代码。该工具包旨在提供创建您自己的反射加载器的参考，该加载器将被 Beacon 使用。

Cobalt Strike 反射加载器从已编译的目标文件（.o）的 .text 部分提取可执行代码，且大小不能超过 5k（版本 4.4）。版本 4.5 增加了对 5k（默认）和 100k 自定义反射加载器的支持。

## 版本 4.5 更新

增加大小

添加了新的钩子 BEACON_RDLL_SIZE，用于指定自定义加载器的大小，可以是 5k 或 100k。这个增加会在您的负载中反映出来。

工具包

udrl 和 artifact 工具包的生成脚本已更新，以允许自定义大小，以确保为您的加载器提供足够的空间。

### UDRL 和可塑 C2 概要考虑

在使用默认反射加载器并生成 Beacon 时，有一些设置会影响 Beacon 的运行配置和加载器，这些设置在生成负载时会自动处理。这使操作员能够在概要中更改这些设置，从而修改生成负载的方式以及在内存中的外观。

在使用用户定义的反射加载器时，这些设置被插入到 Beacon 的运行配置中，但由于用户定义了反射加载器，因此不可能像默认情况下那样修改反射加载器。用户需要相应地修改他们的反射加载器。

例如，如果您正在使用 URDL 工具包中的示例加载器，加载器中没有任何代码来基于映像头中存储的信息执行任何条件设置。这可能会导致 Beacon 出现您不希望出现的运行时问题，因为它与您的可塑 C2 概要中的设置不匹配。如果您从头开始编写自己的反射加载器，您将不得不处理相同类型的问题。

### 要考虑的设置

以下是在将可塑 C2 概要选项 stage.sleepmask 设置为 TRUE 时要考虑的设置。

stage.userwx

这个设置是一个布尔值，通知默认加载器是否使用 RWX 或 RX 内存。在运行时，Beacon 将包括或不包括用于遮蔽的 .text 部分。如果设置为 TRUE，则您的自定义加载器需要将 .text 部分的保护设置为 RWX，否则 Beacon 将崩溃。如果设置为 FALSE，则您的自定义加载器应将 .text 部分的保护设置为 RX，因为 .text 部分将不会被遮蔽。

stage.obfuscate

这个设置是一个布尔值，通知默认加载器是否复制头部或不复制头部到内存。在运行时，Beacon 将包括或不包括用于遮蔽的头部部分。如果设置为 TRUE，则您的用户定义的反射加载器不应复制头部到内存，因为 Beacon 不会遮蔽头部部分。如果设置为 FALSE，则您的用户定义加载器应将头部复制到内存，因为 Beacon 将遮蔽头部部分。

根据您的反射加载器的复杂程度，您需要确保可塑 C2 概要中的设置与 Beacon 负载加载到内存的方式兼容。使用 `BEACON_RDLL_GENERATE` 和 `BEACON_RDLL_GENERATE_LOCAL` 的侵略者脚本钩子，您可以使用侵略者脚本 pe_* 函数来修改您的反射加载器。

### 处理超过 5k 的 UDRL

#### 超过 5k 的加载器

您可以使用 BEACON_RDLL_SIZE 钩子将此空间增加到 100k。URDL 工具包的构建脚本的第一个参数是 RDLL_SIZE 值，可以是 0、5 或 100。值 5 将使用 5K 反射加载器，值 100 将使用 100K 反射加载器。根据 Cobalt Strike 版本，值 0 会产生不同的结果。

对于 4.8 及更早版本，值 0 将使用 5K 反射加载器。

对于 4.9 及更高版本，值 0 将不包括 Beacon dll 中的反射加载器空间，适用于带有预置加载器（sRDI/Double Pulsar）的用途，比如 udrl-vs 工具包中的加载器。

如果您使用 udrl 工具包，那么必须使用值 5 或 100，因为该工具包仅支持 stomped "Stephen Fewer" 风格的加载器。

#### 工件工具包考虑

如果您使用基于 Cobalt Strike 提供的工具包的工件工具包，默认的 stagesize 值支持 5K 反射加载器。工件工具包构建脚本中有参数，可以设置 stagesize 和 rdll_size 值。如果 stagesize 值不符合 rdll_size 值基础的最低要求大小，构建将失败并显示错误。

#### 武器库工具包考虑

如果您使用武器库工具包来构建工件和 udrl 工具包，可以在 arsenal_kit.config 文件中设置 rdll_size 和 artifactkit_stage_size 设置。

---

## 示例

`kits/udrl/src` 目录中的示例代码基于 Stephen Fewer 的经典反射加载器 https://github.com/stephenfewer/ReflectiveDLLInjection 并进行了修改。支持使用 MinGW（Windows 的极简 GNU）进行编译，这基于这个反射加载器项目 https://github.com/boku7/BokuLoader，由 Bobby Cooke 和 Santiago Pecin 开发。

### 可塑 C2 概要设置

为了使这个示例与 Cobalt Strike 兼容，请在 stage 部分使用以下可塑 C2 概要设置。有些设置不受支持，请参阅下面的列表。之所以不支持某些设置，是因为这需要更复杂的实现，超出了简单示例的范围。

```
stage {
   # 以下设置支持此 UDRL 示例
   set checksum       "<your_value>";
   set cleanup        "<true|false>";
   set compile_time   "<your_value>";
   set image_size_x86 "<your_value>";
   set image_size_x64 "<your_value>";
   set name           "<your_value>";
   set rich_header    "<your_value>";
   set sleep_mask     "<true|false>";
   set string         "<your_value>";
   set stringw        "<your_value>";
   
   transform-x86 {
      prepend "<your value>";
      append  "<your value";
      strrep "<orig_str>" "<new_str>";
   }
   transform-x64 {
      prepend "<your value>";
      append  "<your value";
      strrep "<orig_str>" "<new_str>";
   }
   
   # 以下设置不支持此 UDRL 示例。
   # 此 UDRL 示例使用一些设置的硬编码决策
   # 或者完全忽略它们
   set allocator    "VirtualAlloc";
   set userwx       "true";
   set stomppe      "false";
   set obfuscate    "false";
   set smartinject  "false";
   set entry_point  "<ignored>";
   set magic_mz_x86 "<ignored>";
   set magic_mz_x64 "<ignored>";
   set magic_pe     "<ignored>";
   set module_x86   "<ignored>";
   set module_x64   "<ignored>";
}
```

### 对加载器的修改

已进行了修改以删除未使用的代码并添加新的代码，以使其能够与 Cobalt Strike 配合使用。

从 Stephen Fewer 的反射加载器项目中获取以下文件开始。
- dll/src/ReflectiveDLLInjection.h
- dll/src/ReflectiveLoader.h
- dll/src/ReflectiveLoader.c

#### ReflectiveDLLInjection.h

添加的代码确保加载器遵循我们所需的执行路径。


```
#if defined _M_X64
#define REFLECTIVEDLLINJECTION_VIA_LOADREMOTELIBRARYR
#define REFLECTIVEDLLINJECTION_CUSTOM_DLLMAIN
#define WIN_X64
#elif defined _M_IX86
#define REFLECTIVEDLLINJECTION_VIA_LOADREMOTELIBRARYR
#define REFLECTIVEDLLINJECTION_CUSTOM_DLLMAIN
#define WIN_X86
#endif
```


#### ReflectiveLoader.h

已进行以下更改，以支持使用 MinGW 进行构建。
- 将 Winsock2.h 更改为 winsock2.h
- 删除了 '#pragma intrinsic( _rotr );' 行

删除以下宏，因为不支持在 ARM 上进行编译。
- IMAGE_REL_BASED_ARM_MOV32A
- IMAGE_REL_BASED_ARM_MOV32T
- ARM_MOV_MASK
- ARM_MOV_MASK2
- ARM_MOVW
- ARM_MOVT

#### ReflectiveLoader.c

删除受 '#ifdef WIN_ARM' 宏控制的代码，因为不支持在 ARM 上进行编译。

删除以下行以支持使用 MinGW 进行构建。调用者函数由文件底部的汇编实现替代。



```
//===============================================================================================//
#pragma intrinsic( _ReturnAddress )
// 此函数不能被编译器内联，否则我们将得到意外的地址。理想情况下，此代码将使用 /O2 和 /Ob1 开关编译。如果我们能够利用 RIP 相对寻址，那将是额外加分，但我认为在当前的编译器内在中无法使用（而且在 x64 下没有内联汇编可用）。
__declspec(noinline) ULONG_PTR caller( VOID ) { return (ULONG_PTR)_ReturnAddress(); }
//===============================================================================================//
```

在注释 1 和 2 代码注释后添加了以下函数原型定义。

```
DLLEXPORT ULONG_PTR WINAPI ReflectiveLoader( LPVOID lpParameter );
#ifdef WIN_X64
__declspec(noinline) ULONG_PTR caller( VOID );
#else
__declspec(noinline) ULONG_PTR caller( VOID ) asm ("caller");
#endif
```

在文件末尾添加了以下汇编代码，以定义 caller 函数。这替代了原始的 caller 函数，以支持 MinGW 进行编译。

```
__asm__(
#ifdef WIN_X64
"caller: \n"
    "mov rax, [rsp] \n"            // 获取返回地址
    "ret \n"
#else
"caller: \n"
    "mov eax, [esp] \n"            // 获取返回地址
    "ret \n"
#endif
);
```

# 编译

使用提供的 ./build.sh 脚本编译此示例，该脚本使用 MinGW 编译器。

```
用法: ./build <rdll_size> <输出目录>
```


# 加载到 Cobalt Strike

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<output directory>\udrl\udrl.cna`

创建一个负载，以在加载器的脚本控制台中查看成功提取的结果。




```
[11:38:57] [udrl_kit.cna] UDRL Kit Loaded
[11:38:57] [udrl_kit.cna] UDRL - BEACON_RDLL_SIZE hook
[11:38:57] [udrl_kit.cna] UDRL - Use the 5K Reflective Loader
[11:38:57] [udrl_kit.cna] UDRL - BEACON_RDLL_GENERATE hook
[11:38:57] [udrl_kit.cna] UDRL - resources/beacon.x64.dll
[11:38:57] [udrl_kit.cna] UDRL - /home/arsenal-kit/dist/udrl/ReflectiveLoader.x64.o
[11:38:57] [udrl_kit.cna] UDRL - Length 3266
[11:38:57] [udrl_kit.cna] UDRL - Extracted loader length 2432
[11:38:57] [udrl_kit.cna] UDRL - Rich header will be replaced using the header from the profile.
[11:38:57] [udrl_kit.cna] UDRL - Compile time will be updated with this timestamp: 12 Dec 2017 05:05:32
[11:38:57] [udrl_kit.cna] UDRL - Image size will be updated with this value: 4661248
[11:39:01] [udrl_kit.cna] UDRL - Checksum will be updated with this value: 10010
[11:39:01] [udrl_kit.cna] UDRL - Export name of the dll will be updated to: logger.dll
```


# 参考资料

- Stephen Fewer 的经典反射加载器：https://github.com/stephenfewer/ReflectiveDLLInjection
- Bobby Cooke 和 Santiago Pecin 的反射加载器项目：https://github.com/boku7/BokuLoader

# 修改

鼓励您对此代码进行修改并在您的项目中使用。请不要重新分发此源代码，它不是开源的。它作为授权的 Cobalt Strike 用户的福利提供。

# 许可证

此代码受 Cobalt Strike 的最终用户许可协议约束。完整的许可协议位于：

https://www.cobaltstrike.com/license

此代码受 Stephen Fewer 的反射加载器项目许可协议约束。完整的许可协议位于：

https://github.com/stephenfewer/ReflectiveDLLInjection/blob/master/LICENSE.txt
