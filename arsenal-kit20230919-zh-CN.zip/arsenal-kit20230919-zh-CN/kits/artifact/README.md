# 工件工具包

该软件包包含Cobalt Strike的工件工具包的源代码。此工具包旨在简化开发抗病毒安全工件的过程。

Cobalt Strike使用来自此工具包的工件生成可执行文件和DLL，这些文件对某些防病毒产品安全。加载附带的artifacts.cna脚本以强制Cobalt Strike使用您的工件而不是内置工件。

Cobalt Strike在以下位置使用这些工件：

- 攻击 -> Packages -> Windows可执行文件
- 攻击 -> Packages -> Windows可执行文件（S）
- 攻击 -> Web驱动 -> 脚本化的Web传递（bitsadmin和exe）
- Beacon的 'elevate svc-exe' 命令
- Beacon的 'jump psexec' 和 'jump psexec64' 命令

#### 工件工具包设置的支持
工件工具包已实现新的别名 'ak-settings' 以支持修改以下设置的能力：

- service - 修改从PSEXEC_SERVICE挂钩返回的服务名称
- spawnto_x86 - 修改SERVICE EXE工件的迁移使用的进程。
- spawnto_x64 - 修改SERVICE EXE工件的迁移使用的进程。

spawnto_x86 和 spawnto_x64 设置将尝试使用Malleable C2配置文件中的 .post-ex.spawnto_[x86|x64] 设置进行初始化，但存在一些需要满足的条件。当发生这些条件时，将使用有效的默认值。这些设置不支持超过63个字符、空值和环境变量替换。

在以前的工件工具包版本中，这些设置可以在源代码中更新，然后重新构建工件工具包。现在，通过 'ak-settings' 命令，操作员可以根据需要修改这些设置以生成工件。

示例：
```
03/31 11:14:13 beacon> ak-settings
03/31 11:14:13 [*] artifact kit settings:
03/31 11:14:13 [*]    service     = 'updatesvc'
03/31 11:14:13 [*]    spawnto_x86 = 'C:\Windows\SysWOW64\dllhost.exe'
03/31 11:14:13 [*]    spawnto_x64 = 'C:\Windows\System32\svchost.exe'
03/31 11:16:02 beacon> ak-settings service timesvc
03/31 11:16:02 [*] Updating the psexec service name to 'timesvc'
03/31 11:16:02 [*] artifact kit settings:
03/31 11:16:02 [*]    service     = 'timesvc'
03/31 11:16:02 [*]    spawnto_x86 = 'C:\Windows\SysWOW64\dllhost.exe'
03/31 11:16:02 [*]    spawnto_x64 = 'C:\Windows\System32\svchost.exe'
03/31 11:18:45 beacon> jump psexec64 TARGET smb
03/31 11:18:45 [*] Tasked beacon to run windows/beacon_bind_pipe (\\.\pipe\xyz) on TARGET via Service Control Manager (\\TARGET\ADMIN$\timesvc.exe)
03/31 11:18:49 [+] host called home, sent: 295101 bytes
03/31 11:18:52 [+] received output:
Started service timesvc on TARGET
03/31 11:18:52 [+] established link to child beacon: 111.22.333.444
```
您会注意到新的beacon将在 'svchost.exe' 进程下运行。

# 工作原理

大多数防病毒产品使用签名来检测已知的恶意软件。为了击败加密和打包工具，这些产品使用虚拟机沙箱来逐步执行二进制文件，并检查每个步骤是否与已知签名数据库匹配。A/V沙箱不会模拟程序可能执行的所有操作。工件工具包二进制文件将shellcode强制通过许多A/V引擎无法模拟的过程。这导致A/V引擎放弃处理工件。

### dist-mailslot/（在src-common/bypass-mailslot.c中实现）
```
此绕过创建一个邮槽以提供混淆的shellcode和一个客户端来读取它。一旦客户端读取混淆的shellcode，它会对其进行解码。

此技术来自Mr. Un1k0d3r的第5季第8集会话
https://mr.un1k0d3r.com/portal/index.php
```

### dist-peek/（在src-common/bypass-peek.c中实现）
```
这种绕过技术来自mihi的关于使用Metasploit进行防病毒规避的真相与神话。
请参阅http://schierlm.users.sourceforge.net/avevasion.html中的Antivirus Sandbox Evasion部分
```

### dist-pipe/（在src-common/bypass-pipe.c中实现）
```
此绕过创建一个命名管道以提供混淆的shellcode和一个客户端来读取它。一旦客户端读取混淆的shellcode，它会对其进行解码。
```

### dist-readfile/（在src-common/bypass-readfile.c中实现）
```
此绕过打开当前的工件文件，跳到存储shellcode的位置，读取它并对其进行解码。这是与Cobalt Strike一起加载的默认工件工具包。
```

### dist-readfile-v2/（在src-common/bypass-readfile-v2.c中实现）
```
此绕过打开当前的工件文件，从文件中读取数据，用payload覆盖已读取的数据，然后对其进行解码。
```

### dist-template/（在src-common/template.c中实现）
```
这种绕过技术不会绕过任何防病毒软件。它是一个模板。
```


## 与用户定义的反射加载器集成

可以更改 `stagesize` 以适应需要较大空间的需要，用于已使用 `BEACON_RDLL_SIZE` 挂钩进行大型自定义反射加载器的beacons。指定的大小必须等于或大于要嵌入所选工件的payload大小。在构建工件工具包时，将 `stagesize` 设置为一个参数。

BEACON_RDLL_SIZE 挂钩将返回值 0、5 或 100。值 5 将使用5KB的反射加载器，而值 100 将使用100KB的反射加载器。根据Cobalt Strike版本，值0有不同的结果。

对于4.8及更早的版本，值0将使用5KB的反射加载器。

对于4.9及更高的版本，值0将不在beacon的DLL中包含反射加载器的空间，并且适用于带有预加载加载器（如udrl-vs工具包中找到的加载器）的情况。在这种情况下，`stagesize` 需要包括加载器和beacon的大小，这可能会比5KB的大小大。

```
0KB用户定义的反射加载器大小 = 310272
5KB用户定义的反射加载器大小 = 310272
100KB用户定义的反射加载器大小 = 444928
```

## 自定义二进制资源

可以使用 src-main/resource.c 文件配置二进制元数据，用于设置文件元数据、图标等。在构建工件工具包时启用为一个参数。

## 使用系统调用

工件将使用标准的Windows API或其中一个系统调用方法。 SysWhispers3公共存储库用于生成系统调用的代码，并进行了额外的修改以适应工件工具包。

在SysWhispers3项目中被引用为 'jumper' 的系统调用方法将在工件工具包中被称为 'indirect'，以保持与Cobalt Strike术语的一致。这会影响文件名、构建脚本和文档，但不会影响生成文件中的代码。

可以在以下系统调用方法之间进行选择。

方法              |     描述
--------------------|----------------------------------------
none                | 使用标准的Windows API函数。
embedded            | 使用嵌入方法。
indirect            | 使用间接方法。
indirect_randomized | 使用间接随机方法。

嵌入方法可能会被防病毒产品捕获。

Credits:
 - https://github.com/klezVirus/SysWhispers3
 - https://www.mdsec.co.uk/2020/12/bypassing-user-mode-hooks-and-direct-invocation-of-system-calls-for-red-teams
 - https://github.com/helpsystems/nanodump

# 使用方法

```
./build.sh <技术> <分配器> <阶段大小> <rdll大小> <资源文件> <堆栈欺骗> <系统调用> <输出目录>

技术 - 以空格分隔的列表
分配器 - 设置反射加载器的内存分配方式。
有效值 [HeapAlloc, VirtualAlloc, MapViewOfFile]
阶段大小 - 用于设置beacon阶段所需空间的整数。
对于0K RDLL阶段大小应该为310272或更大
对于5K RDLL阶段大小应该为310272或更大
对于100K RDLL阶段大小应该为444928或更大
RDLL大小 - 用于指定RDLL大小的整数。有效值 [0, 5, 100]
资源文件 - true或false，以包括资源文件
堆栈欺骗 - true或false，以使用堆栈欺骗技术
系统调用 - 设置系统调用方法
有效值 [none embedded indirect indirect_randomized]
输出目录 - 保存输出的目标目录
```

示例： 
```
./build.sh "peek pipe readfile" HeapAlloc 310272 5 true true indirect /tmp/dist
```

您将需要以下内容：

- 用于Windows交叉编译的最小GNU工具 - apt-get install mingw-w64

# 如何添加新的绕过

1. 在 src-common/ 中创建一个文件，命名为 bypass-[你的技术名称]。c
2. 运行 `./build.sh [你的技术名称] HeapAlloc 361000 5 true true none /tmp/dist`

# 加载到Cobalt Strike

要使用新的工件工具包，请加载artifact.cna到Cobalt Strike中。工件工具包的每个变体都位于自己的文件夹中。artifact.cna脚本包含Cortana过滤器，告诉Cobalt Strike使用您的工件工具包而不是内置选项。

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<output directory>/<technique>/artifact.cna`

# 修改

鼓励您对此代码进行修改并在您的渗透测试中使用。不要重新分发此源代码。它不是开源的。它是授权的Cobalt Strike用户的一个好处。

# 许可

此代码受Cobalt Strike的最终用户许可协议约束。完整的许可协议在：

https://www.cobaltstrike.com/license
