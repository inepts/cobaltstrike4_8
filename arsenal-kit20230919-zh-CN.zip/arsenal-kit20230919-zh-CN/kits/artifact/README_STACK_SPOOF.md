# 线程堆栈欺骗

多年来，AV / EDR 检测机制不断改进，其中使用的一种具体技术是线程堆栈检查。这种技术用于确定调用函数或API的进程的合法性。

![堆栈转储截图](images/stack_dump.PNG)

上面的堆栈跟踪显示了与任何模块都没有映射的地址。这可能被视为AV / EDR 引擎的潜在指示器。

一些项目已经发布，例如 mgeeky 的
[https://github.com/mgeeky/ThreadStackSpoofer](https://github.com/mgeeky/ThreadStackSpoofer)，已被证明有效。

正如 ThreadStackSpoofer 文档中所述，该实现是有效的，但它仍有改进的空间，因为在这种情况下，在休眠之前返回地址被无效化（清零），因此无法执行堆栈遍历。

允许线程堆栈切换的机制之一是Microsoft Fibers
[https://docs.microsoft.com/en-us/windows/win32/procthread/fibers](https://docs.microsoft.com/en-us/windows/win32/procthread/fibers)。

Arsenal Kit 已经更新，使用Microsoft Fiber 函数来实现堆栈欺骗。这种技术不会使堆栈无效，它会练习正常的代码执行工作流程，利用Microsoft Fibers 的堆栈切换副作用。

![堆栈转储截图 sp](images/stack_dump_sp.PNG)

现在，可以使用 thefLink 的 Hunt Sleeping Beacons 项目来扫描目标
[https://github.com/thefLink/Hunt-Sleeping-Beacons](https://github.com/thefLink/Hunt-Sleeping-Beacons)

![查找休眠 Beacon 的截图](images/hunt_sleep_beacons.PNG)

# 如何使用

要启用/禁用 Arsenal Kit 中的堆栈欺骗技术，您需要修改 arsenal_kit.config 文件。

1) 将 artifactkit_stack_spoof 设置为 true（默认值）或 false
2) 构建工具包 `build_arsenal_kit.sh`
3) 加载脚本 - 在 Cobalt Strike -> 脚本管理器 -> 加载 `dist/arsenal_kit.cna`
