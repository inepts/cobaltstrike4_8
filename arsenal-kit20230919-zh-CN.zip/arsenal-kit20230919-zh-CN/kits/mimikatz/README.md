# Mimikatz Kit

该软件包包含了用于Colbalt Strike的预构建的Mimikatz dll。该工具包将尝试与最新的Mimikatz版本保持同步，因此您可以下载该软件包，并获得最新的Mimikatz命令，以与您当前版本的Cobalt Strike一起使用。

资源目录中包含的dll列表：
- mimikatz-chrome.x86.dll
- mimikatz-chrome.x64.dll
- mimikatz-full.x86.dll
- mimikatz-full.x64.dll
- mimikatz-min.x86.dll
- mimikatz-min.x64.dll
- mimikatz-max.x86.dll
- mimikatz-max.x64.dll

Mimikatz的dll是自定义构建的dll，包括一个反射式dll加载程序和修改后的代码，以减小与传统的1-MB大小限制一起使用的文件大小。从Cobalt Strike 4.6发布开始，此限制可以进行修改，但默认仍然为1-MB，这就是为什么dll仍然是自定义构建的原因。

从Arsenal Kit的20221205版本开始，还将提供Mimikatz dll的附加构建版本。这些dll不会被默认使用，需要对script_template.cna以及tasks_max_size可变C2配置文件设置进行修改。与'max'版本的区别在于没有修改Mimikatz代码以减小dll的大小。仍然添加了自定义反射式dll加载程序。

对于大多数用户来说，mimikatz-full版本将足够满足您的用例要求，但如果您需要一些已删除的功能，请尝试mimikatz-max版本。

要使用mimikatz-max版本，需要更新mimikatz/script_template.cna文件。您只需更改要注释的代码行，脚本中有详细信息。还需要设置malleable C2配置文件的'tasks_max_size'设置，以使mimikatz-max.x64.dll的大小足够大，可以通过。

注意事项：
 - 要使用mimikatz-max.<arch>.dll版本，需要Cobalt Strike 4.6或更高版本
 - tasks_max_size设置需要足够大以传送dll。
 - tasks_max_size设置会影响beacon的生成。有关更多信息，请参阅tasks_max_size设置文档。

# 加载到Cobalt Strike

要使用Mimikatz Kit，请将mimikatz.cna加载到Cobalt Strike中。

打开脚本管理器，Cobalt Strike -> 脚本

加载 `<output directory>/mimikatz/mimikatz.cna`

# 许可

此代码受Cobalt Strike的最终用户许可协议约束。完整的许可协议位于：

[https://www.cobaltstrike.com/license](https://www.cobaltstrike.com/license)

Mimikatz由Benjamin Delpy创建。
[https://github.com/gentilkiwi/mimikatz](https://github.com/gentilkiwi/mimikatz)

CC BY 4.0 许可证
[https://creativecommons.org/licenses/by/4.0](https://creativecommons.org/licenses/by/4.0)
