# Cobalt Strike Arsenal Kit

(c) 2012-2023 Fortra, LLC及其关联公司。所有商标和注册商标均为其各自所有者的财产。

Cobalt Strike Arsenal Kit的构建脚本

汉化来自https://github.com/inepts/cobaltstrike4_8
## 描述

Arsenal kit是将各个工具包组合成单个工具包的组合。构建此工具包将生成一个名为`dist/arsenal_kit.cna`的单个Aggressor脚本，可以加载该脚本而不是加载各个工具包。该工具包由`arsenal_kit.config`文件控制，该文件配置了使用`build_arsenal_kit.sh`脚本构建的工具包。

各个工具包仍然可以独立使用。每个工具包都有自己的Aggressor脚本文件，位于`dist/<kit_name>/<kit_name>.cna`，可以单独加载。有关详细信息，请参考工具包的自述文件。

`build_arsenal_kit.sh`脚本会构建`arsenal_kit.config`文件中启用的工具包，对于每个启用的工具包，它会执行`kits/<kit_name>/build.sh`脚本。要构建单个工具包，请切换到`kits/<kit_name>`目录并执行`build.sh`。对于各个工具包的`build.sh`脚本，请不带参数运行以查看更多有关所需参数的帮助文本。

请注意，`udrl-vs`工具包是独立的，必须单独构建。它不包括在`arsenal_kit.config`文件或`build_arsenal_kit.sh`脚本中。

## 工具包和支持的Cobalt Strike版本

工具包              | Cobalt Strike 版本
----------------------|----------------------
Artifact              | 4.x
Sleepmask             | 4.7及更高版本
UDRL                  | 4.4及更高版本
UDRL-VS               | 4.4及更高版本
Mimikatz (20220919)   | 4.5及更高版本
Resource              | 4.x
Process Inject        | 4.5及更高版本

- 未包括在内
  - Elevate Kit
  - applet
  - powerapplet

版本4.4的sleepmask工具包可以在https://download.cobaltstrike.com/scripts下载。
版本4.5和4.6的sleepmask工具包可以在arsenal kits 20230911及更早版本中获取。

## 工具包文件和目录说明

位置                             | 描述
-------------------------------------|------------
arsenal_kit.config                   | Arsenal kit配置
build_arsenal_kit.sh                 | Arsenal kit构建脚本
templates/                           | Aggressor脚本全局模板
templates/arsenal_kit.cna.template   | Arsenal kit模板基本脚本
templates/helper_functions.template  | 帮助函数模板脚本
dist/                                | 构建输出的默认位置
kits/                                | 工具包的源代码
kits/< KIT >/script_template.cna     | 工具包的基本模板

## 要求

该工具包设计用于在Linux平台上运行。已在基于Debian的Linux上进行测试。

您需要以下内容：

- 最小GNU for Windows交叉编译器 - `apt-get install mingw-w64`

## 快速开始

1) 查看和编辑`arsenal_kit.config`以将包括的工具包设置为true
2) 构建工具包 `build_arsenal_kit.sh`
3) 加载脚本 - 在Cobalt Strike -> 脚本管理器 -> 加载 `dist/arsenal_kit.cna`

使用挂钩的命令将在脚本控制台中显示输出。

生成工具包的示例（仅启用了工具包）：

```
[10:16:12] [arsenal_kit.cna] ######################################
[10:16:12] [arsenal_kit.cna] # Cobalt Strike Arsenal Kit
[10:16:12] [arsenal_kit.cna] # (c) 2012-2023 Fortra, LLC and its group of companies. All trademarks and registered trademarks are the property of their respective owners.
[10:16:12] [arsenal_kit.cna] ######################################
[10:16:12] [arsenal_kit.cna] Artifact Kit Loaded
[10:16:25] [arsenal_kit.cna] Artifact - EXECUTABLE_ARTIFACT_GENERATOR hook
[10:16:25] [arsenal_kit.cna] Artifact - /home/arsenal-kit/dist/artifact/artifact64big.exe
[10:16:25] [arsenal_kit.cna] Artifact - Length 265737
```


# 修改

鼓励您对此代码进行修改并在您的工作中使用这些修改。请不要重新分发此源代码。它不是开源的。它是为有许可的Cobalt Strike用户提供的福利。

每个工具包都有详细信息，说明如何自定义。

# 许可

此代码受Cobalt Strike的最终用户许可协议约束。完整的许可协议位于：

https://www.cobaltstrike.com/license

每个工具包中的自述文件将包括有关该特定工具包的特定许可信息。
